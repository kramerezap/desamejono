@extends('layouts.master')

@section('content')

<!-- banner -->
<div class="banner" id="home">
			<img src="Assets/images/bubbit.jpg" alt="" class="img-fluid" width="100%" height="60%" />
	
<!-- //banner -->
<center>
<!-- about -->
<section class="about py-5" style="background-color: white;">

	<div class="container py-md-3">
		
			<div class="col-lg-8">
				<h3 class="about-left" align="center">Selamat Datang di Website Desa Mejono</h3>
				<p class="mt-sm-4 mt-3" align="justify">Desa Mejono adalah sebuah Desa yang berada di Kecamatan Plemahan Kabupaten Kediri dengan mayoritas penduduknya sebagai petani. Desa Mejono dibagi menjadi 2 Dusun, yaitu Dusun sumbermulyo dan Dusun Mejono.</p>
				<p class="mt-sm-4 mt-3" align="justify">Desa Mejono terletak di bagian ujung selatan dari kecamatan Plemahan tepat berbatasan dengan desa Jambu Kecamatan Kayen Kidul. dengan letak geografis terletak di aliran sungai gronjong membuat desa Mejono menonjol di bidang agraria khususnya peranian. Selain itu desa Mejono memiliki lahan persawahan yang luas dikarenakan sebagian besar penduduk desa Mejono bekerja sebagai petani. Fakor keunggulan lahan pertanian dan lokasi persawahan yang luas menjadikan desa Mejono lebih unggul di bidangn pertanian. </p>
				
		
			</div>
		
	</div>
	</div>
</section>
<!-- //about -->
</center>

@endsection