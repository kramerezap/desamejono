@extends('layouts.master')

@section('content')


<!-- //banner -->

<!-- about -->
<section class="about py-5">
	<div class="container py-md-3">
<br>
		<h2 class="heading text-center mb-sm-5 mb-4">Struktur Organisasi</h2>
		<div class="row">
			<div class="col-lg-7">
				<img src="Assets/images/strukturorganisasi.png" class="img-fluid" alt="" />
			
			
				
				
			</div>
			<div class="col-lg-1"></div>
			<div class="col-lg-4 col-md-8 dental" style="background-color: #F5F5F5 ; border-radius: 1%; height: 415px ">
				<br>
				<img src="Assets/images/gronjong.jpg" class="img-fluid" alt="" />
				<br>
				<br>

				<h6 style="border-bottom: solid 1px #D3D3D3;  height: 40px; padding-top: 10px  "><a href="profil" style="color: grey;" >  Visi & Misi</h6>
				
				<h6 style="border-bottom: solid 1px #D3D3D3;  height: 40px;padding-top: 10px  "> <a href="profilsejarah" style=" color: gray">Sejarah Desa</h6>
				
				<h6 style="border-bottom: solid 1px black;  height: 40px;padding-top: 10px  "> <a href="profilstruktur"style=" color: black">Struktur Organisasi</h6>
				<h6 style="border-bottom: solid 1px #D3D3D3;  height: 40px;padding-top: 10px  "><a href="profilanggaran" style=" color: gray"> Anggaran Desa</h6>
				
			
			</div>
		</div>
	</div>
</section>



@endsection